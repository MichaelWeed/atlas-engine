import boto3
import json
import logging
import os

# Configure logging
logger = logging.getLogger()
logger.setLevel(logging.INFO)

# Initialize the Bedrock Runtime client
try:
    model_id = os.environ.get('MODEL_ID')
    bedrock_runtime = boto3.client(service_name='bedrock-runtime')
except Exception as e:
    logger.error(f"Error initializing Bedrock client: {e}")
    bedrock_runtime = None

def lambda_handler(event, context):
    """
    Generates a dynamic sales scenario using Amazon Bedrock.
    """
    if not bedrock_runtime:
        return {
            'statusCode': 500,
            'body': json.dumps({'error': 'Bedrock client not initialized.'})
        }

    # Extract user details from the Step Functions input
    first_name = event.get('firstName', 'Valued')
    last_name = event.get('lastName', 'Prospect')
    prospect_name = f"{first_name} {last_name}".strip()
    # Safe get for chat_transcript (from Lex if passed; default empty)
    chat_transcript = event.get('chat_transcript', '')

    # Construct a detailed prompt for the AI model
    prompt = f"""
Human: Your task is to generate a brief, conversational opening for an AI-powered sales call.
The prospect's name is {prospect_name}.
Context from their prior chat: "{chat_transcript}".

**RULES:**
1.  Generate **one or two simple sentences** of plain, speakable text.
2.  The text should be a friendly, professional call introduction that references their name and our recent chat.
3.  **DO NOT** include any SSML, XML, or tags of any kind (like <speak> or <introduction>).
4.  The output must be 100% plain text, ready to be spoken.

**Example:**
"Hello {prospect_name}, this is Atlas from the AI demo. I'm calling to follow up on the chat we just had about the architecture."

Assistant:
"""


    # Create the request body for the Bedrock API
    body = json.dumps({
        "anthropic_version": "bedrock-2023-05-31",
        "max_tokens": 300,
        "temperature": 0.8,
        "messages": [
            {
                "role": "user",
                "content": [{"type": "text", "text": prompt}]
            }
        ]
    })

    try:
        # Invoke the model
        response = bedrock_runtime.invoke_model(
            body=body,
            modelId=model_id,
            accept='application/json',
            contentType='application/json'
        )

        # Parse the response to get the generated text
        response_body = json.loads(response.get('body').read())
        scenario_text = response_body.get('content', [{}])[0].get('text', '').strip()

        logger.info(f"Successfully generated scenario: {scenario_text[:100]}...")

        # Return the scenario to the Step Function
        return {
            'scenario': scenario_text
        }

    except Exception as e:
        logger.error(f"Error invoking Bedrock model: {e}")
        # Fallback scenario (plain text)
        return {
            'scenario': f"Hello {prospect_name}, this is Atlas from the AI demo, calling to follow up on our chat."
        }